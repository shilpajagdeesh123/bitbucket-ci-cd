#!/usr/bin/env bash
set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 2
cd "$REPO_ROOT" || exit 2
FAILED=0

report() {
  echo ""
  echo "[SECURITY] $1 detected"
  echo "  File: $2"
  echo "  Line: $3"
  FAILED=1
}

# Values in these explicit encrypted forms are allowed.
# Examples: ENC(...), {cipher}..., encrypted:..., vault:...
is_encrypted_value() {
  local value="$1"
  value="$(printf '%s' "$value" | sed -E "s/^[[:space:]]*[\"']?//; s/[\"']?[[:space:]]*$//")"
  printf '%s\n' "$value" | grep -Eiq '^(ENC\(.+\)|\{cipher\}.+|encrypted:.+|vault:.+)$'
}

check_named_secret() {
  local line="$1" pattern="$2" category="$3" file="$4" line_no="$5"
  local value

  # Key names may contain spaces, dots, underscores or hyphens.
  # Assignment separator must be = or :.
  if printf '%s\n' "$line" | grep -Eiq "(^|[^[:alnum:]])${pattern}[[:space:]]*[:=]"; then
  value="$(printf '%s' "$value" | sed -E "s/^[[:space:]]*[\"']?//; s/[\"']?[[:space:]]*$//")"
    [ -n "$(printf '%s' "$value" | tr -d '[:space:]\"'"'"'')" ] || return 0
    if ! is_encrypted_value "$value"; then
      report "$category" "$file" "$line_no"
    fi
  fi
}

UPSTREAM="$(git rev-parse --abbrev-ref --symbolic-full-name '@{u}' 2>/dev/null || true)"
if [ -n "$UPSTREAM" ]; then BASE="$(git merge-base HEAD "$UPSTREAM" 2>/dev/null || true)"; else BASE=""; fi
if [ -n "$BASE" ]; then FILES="$(git diff --name-only --diff-filter=ACMRT "$BASE" HEAD)"; else FILES="$(git ls-tree -r --name-only HEAD)"; fi

for FILE in $FILES; do
  [ -f "$FILE" ] || continue
  case "$FILE" in
    .git/*|node_modules/*|target/*|dist/*|build/*|.security/security-scan.sh|.githooks/pre-push) continue ;;
  esac

  SIZE="$(wc -c < "$FILE" 2>/dev/null || echo 0)"
  case "$SIZE" in ''|*[!0-9]*) SIZE=0 ;; esac
  [ "$SIZE" -le 2097152 ] || continue
  LC_ALL=C grep -Iq . "$FILE" 2>/dev/null || continue

  LINE_NO=0
  while IFS= read -r LINE || [ -n "$LINE" ]; do
    LINE_NO=$((LINE_NO + 1))
    case "$LINE" in *"security-scan: allow"*) continue ;; esac

    check_named_secret "$LINE" '([[:alnum:]]+[._ -])*password|([[:alnum:]]+[._ -])*passwd|([[:alnum:]]+[._ -])*pwd' "Plain-text password" "$FILE" "$LINE_NO"
    check_named_secret "$LINE" '([[:alnum:]]+[._ -])*api[._ -]*key|apikey' "Plain-text API key" "$FILE" "$LINE_NO"
    check_named_secret "$LINE" '([[:alnum:]]+[._ -])*(access[._ -]*token|auth[._ -]*token|bearer[._ -]*token|refresh[._ -]*token|token)' "Plain-text token" "$FILE" "$LINE_NO"
    check_named_secret "$LINE" '([[:alnum:]]+[._ -])*(client[._ -]*secret|secret[._ -]*key|secret)' "Plain-text secret" "$FILE" "$LINE_NO"

    if printf '%s\n' "$LINE" | grep -Eq -- '-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----'; then report "Private key" "$FILE" "$LINE_NO"; fi
    if printf '%s\n' "$LINE" | grep -Eq 'eyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}'; then report "JWT token" "$FILE" "$LINE_NO"; fi
    if printf '%s\n' "$LINE" | grep -Eiq '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'; then report "Email address" "$FILE" "$LINE_NO"; fi
  done < "$FILE"
done

if [ "$FAILED" -ne 0 ]; then
  echo ""
  echo "========================================"
  echo " SECURITY SCAN FAILED - PUSH BLOCKED"
  echo "========================================"
  echo "Plain-text credentials are not permitted. Encrypt the value and retry."
  exit 1
fi

echo "Security scan passed."
exit 0
