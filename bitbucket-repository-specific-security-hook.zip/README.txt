BITBUCKET DATA CENTER - REPOSITORY-SPECIFIC CUSTOM SECURITY HOOK

FILES
- security-pre-receive.sh: custom PRE hook
- install-repository-hook.sh: admin installation helper
- MANUAL-ADMIN-COMMANDS.txt: manual REST commands
- TEST-GUIDE.txt: safe test procedure

FLOW
System admin registers the custom PRE hook once.
The returned hook script ID is associated only with:
  <PROJECT_KEY>/<REPOSITORY_SLUG>

Repository-specific endpoint:
  /rest/api/latest/projects/{projectKey}/repos/{repositorySlug}/hook-scripts/{scriptId}

Developer:
  git clone -> git commit -> git push
Bitbucket:
  pre-receive hook -> scan new lines -> reject/accept

No developer-side .git/hooks setup is required.

SCANNER CHECKS
- hard-coded password
- token
- API key
- secret/client secret
- private key
- JWT-like token
- email address

Existing "Push check":
Keep it unchanged unless your Bitbucket admin confirms it is designed for custom logic.
Install this as a separate PRE hook.

Optional false-positive suppression:
  security-scan: allow

Optional company email allow-list:
  ALLOW_EMAIL_REGEX='@company\.com$'

The script reports finding category, ref, commit, file and line number,
but does not print the detected secret value.

Test first in a non-production repository.
