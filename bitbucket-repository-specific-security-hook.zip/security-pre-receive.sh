#!/usr/bin/env bash
set -u
ZERO="0000000000000000000000000000000000000000"
FAILED=0

report(){ echo "SECURITY VIOLATION: $1"; echo "  Ref: $2"; echo "  Commit: $3"; echo "  File: $4"; echo "  Line: $5"; echo; FAILED=1; }

scan_line(){
  c="$1"; ref="$2"; commit="$3"; file="$4"; ln="$5"
  case "$c" in *"security-scan: allow"*) return 0;; esac
  printf '%s\n' "$c" | grep -Eiq '(password|passwd|pwd)[[:space:]]*[:=][[:space:]]*["'\'']?[^[:space:]"'\'']{4,}' && report "Hard-coded password" "$ref" "$commit" "$file" "$ln"
  printf '%s\n' "$c" | grep -Eiq '(access[_-]?token|auth[_-]?token|bearer[_-]?token|refresh[_-]?token|token)[[:space:]]*[:=][[:space:]]*["'\'']?[A-Za-z0-9._~+/=-]{8,}' && report "Token" "$ref" "$commit" "$file" "$ln"
  printf '%s\n' "$c" | grep -Eiq '(api[_-]?key|apikey)[[:space:]]*[:=][[:space:]]*["'\'']?[A-Za-z0-9._~+/=-]{8,}' && report "API key" "$ref" "$commit" "$file" "$ln"
  printf '%s\n' "$c" | grep -Eiq '(client[_-]?secret|secret[_-]?key|secret)[[:space:]]*[:=][[:space:]]*["'\'']?[A-Za-z0-9._~+/=-]{8,}' && report "Secret" "$ref" "$commit" "$file" "$ln"
  printf '%s\n' "$c" | grep -Eq -- '-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----' && report "Private key" "$ref" "$commit" "$file" "$ln"
  printf '%s\n' "$c" | grep -Eq 'eyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}' && report "JWT token" "$ref" "$commit" "$file" "$ln"
  if printf '%s\n' "$c" | grep -Eiq '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'; then
    if [ -n "${ALLOW_EMAIL_REGEX:-}" ] && printf '%s\n' "$c" | grep -Eiq "$ALLOW_EMAIL_REGEX"; then :; else report "Email address" "$ref" "$commit" "$file" "$ln"; fi
  fi
}

scan_commit(){
  commit="$1"; ref="$2"
  git diff-tree --root --no-commit-id --unified=0 -r --no-ext-diff --text "$commit" 2>/dev/null |
  awk '
    /^\+\+\+ b\// {file=substr($0,7); next}
    /^@@ / {split($0,a,"+"); split(a[2],b," "); split(b[1],n,","); line=n[1]-1; next}
    /^\+/ && !/^\+\+\+/ {line++; print file "\t" line "\t" substr($0,2); next}
    /^ / {line++; next}
  ' |
  while IFS="$(printf '\t')" read -r file ln content; do
    [ -n "$file" ] || continue
    case "$file" in *.png|*.jpg|*.jpeg|*.gif|*.pdf|*.zip|*.jar|*.war|*.ear|*.class|*.exe|*.dll|*.so) continue;; esac
    scan_line "$content" "$ref" "$commit" "$file" "$ln"
  done
}

while read -r oldrev newrev refname; do
  [ "$newrev" = "$ZERO" ] && continue
  if [ "$oldrev" = "$ZERO" ]; then
    commits="$(git rev-list "$newrev" --not --all 2>/dev/null || true)"
    [ -n "$commits" ] || commits="$newrev"
  else
    commits="$(git rev-list "$oldrev..$newrev" 2>/dev/null || true)"
  fi
  for commit in $commits; do scan_commit "$commit" "$refname"; done
done

if [ "$FAILED" -ne 0 ]; then
  echo "SECURITY SCAN FAILED - PUSH REJECTED"
  exit 1
fi
echo "Security secret scan passed."
exit 0
