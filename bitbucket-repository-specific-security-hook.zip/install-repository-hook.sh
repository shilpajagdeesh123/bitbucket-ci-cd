#!/usr/bin/env bash
set -euo pipefail
if [ $# -ne 4 ]; then
  echo "Usage: $0 <BITBUCKET_URL> <PROJECT_KEY> <REPO_SLUG> <SYS_ADMIN_USER>"
  exit 2
fi
URL="${1%/}"; PROJECT="$2"; REPO="$3"; USER="$4"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOK="$DIR/security-pre-receive.sh"

echo "Registering PRE hook..."
RESP=$(curl -sS -u "$USER" -X POST "$URL/rest/api/latest/hook-scripts" \
  -H "Accept: application/json" -H "X-Atlassian-Token: no-check" \
  -F "content=@$HOOK" -F "name=Security Secret Scanner" \
  -F "description=Repository-specific secret scanner" -F "type=PRE")
echo "$RESP"
ID=$(printf '%s\n' "$RESP" | sed -n 's/.*"id"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' | head -1)
[ -n "$ID" ] || { echo "Could not read hook ID"; exit 1; }

echo "Associating hook ONLY with $PROJECT/$REPO..."
curl -sS -u "$USER" -X PUT \
  "$URL/rest/api/latest/projects/$PROJECT/repos/$REPO/hook-scripts/$ID" \
  -H "Accept: application/json" -H "Content-Type: application/json" \
  --data '{"triggerIds":[]}'
echo
echo "Done. Hook ID=$ID Repository=$PROJECT/$REPO"
