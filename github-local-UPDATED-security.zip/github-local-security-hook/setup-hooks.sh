#!/usr/bin/env bash
set -e

ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || {
  echo "ERROR: Run this command from inside the cloned repository."
  exit 1
}

cd "$ROOT"

if [ ! -f ".githooks/pre-push" ] || [ ! -f ".security/security-scan.sh" ]; then
  echo "ERROR: Required hook/scanner files are missing."
  exit 1
fi

chmod +x .githooks/pre-push .security/security-scan.sh 2>/dev/null || true

git config core.hooksPath .githooks

echo "========================================"
echo " Security hook installed"
echo "========================================"
echo "core.hooksPath = $(git config core.hooksPath)"
echo ""
echo "Every 'git push' in this repository will now run:"
echo "  .githooks/pre-push"
echo "    -> .security/security-scan.sh"
