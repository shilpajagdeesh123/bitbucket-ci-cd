LOCAL GIT SECURITY HOOK SETUP

Repository structure:
  .githooks/
    pre-push
  .security/
    security-scan.sh
  setup-hooks.sh
  setup-hooks.bat

ONE-TIME SETUP AFTER CLONING

Windows Command Prompt:
  setup-hooks.bat

Git Bash / macOS / Linux:
  bash setup-hooks.sh

What setup does:
  git config core.hooksPath .githooks

After setup, every:
  git push

runs:
  .githooks/pre-push
    -> .security/security-scan.sh

Scanner checks:
- hard-coded passwords
- access/auth/bearer/refresh tokens
- API keys
- client/generic secrets
- private key markers
- JWT-like tokens
- email addresses

TEST
1. Create test-security.properties
2. Add: password=TestingPassword123
3. git add test-security.properties
4. git commit -m "test scanner"
5. git push

Expected:
  SECURITY SCAN FAILED
  PUSH BLOCKED BY SECURITY POLICY

IMPORTANT
- This is a LOCAL Git hook. A developer can bypass local hooks.
- Use a server-side pre-receive hook or CI required check as the authoritative enterprise enforcement layer.
- Current version blocks every email address.
