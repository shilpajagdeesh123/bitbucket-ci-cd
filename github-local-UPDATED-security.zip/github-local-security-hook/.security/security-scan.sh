#!/usr/bin/env bash
set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || exit 2
cd "$REPO_ROOT" || exit 2

FAILED=0

report() {
  CATEGORY="$1"
  FILE="$2"
  LINE="$3"

  echo ""
  echo "[SECURITY] $CATEGORY detected"
  echo "  File: $FILE"
  echo "  Line: $LINE"
  FAILED=1
}

UPSTREAM="$(git rev-parse --abbrev-ref --symbolic-full-name '@{u}' 2>/dev/null || true)"

if [ -n "$UPSTREAM" ]; then
  BASE="$(git merge-base HEAD "$UPSTREAM" 2>/dev/null || true)"
else
  BASE=""
fi

if [ -n "$BASE" ]; then
  FILES="$(git diff --name-only --diff-filter=ACMRT "$BASE" HEAD)"
else
  FILES="$(git ls-tree -r --name-only HEAD)"
fi

for FILE in $FILES; do
  [ -f "$FILE" ] || continue

  case "$FILE" in
    .git/*|node_modules/*|target/*|dist/*|build/*|.security/security-scan.sh|.githooks/pre-push)
      continue
      ;;
  esac

  SIZE="$(wc -c < "$FILE" 2>/dev/null || echo 0)"
  case "$SIZE" in
    ''|*[!0-9]*) SIZE=0 ;;
  esac
  [ "$SIZE" -le 2097152 ] || continue

  LC_ALL=C grep -Iq . "$FILE" 2>/dev/null || continue

  LINE_NO=0
  while IFS= read -r LINE || [ -n "$LINE" ]; do
    LINE_NO=$((LINE_NO + 1))

    case "$LINE" in
      *"security-scan: allow"*) continue ;;
    esac

    if printf '%s\n' "$LINE" | grep -Eiq '(^|[^[:alnum:]])(password|passwd|pwd)[[:space:]]*[:=][[:space:]]*["'"'"']?[^[:space:]"'"'"']{4,}'; then
      report "Hard-coded password" "$FILE" "$LINE_NO"
    fi

    if printf '%s\n' "$LINE" | grep -Eiq '(access[_-]?token|auth[_-]?token|bearer[_-]?token|refresh[_-]?token|token)[[:space:]]*[:=][[:space:]]*["'"'"']?[A-Za-z0-9._~+/=-]{8,}'; then
      report "Token" "$FILE" "$LINE_NO"
    fi

    if printf '%s\n' "$LINE" | grep -Eiq '(^|[^[:alnum:]])(api[[:space:]_.-]*key|apikey)[[:space:]]*[:=][[:space:]]*["'"'"']?[^[:space:]"'"'"']{4,}'; then
      report "API key" "$FILE" "$LINE_NO"
    fi

    if printf '%s\n' "$LINE" | grep -Eiq '(client[_-]?secret|secret[_-]?key|secret)[[:space:]]*[:=][[:space:]]*["'"'"']?[A-Za-z0-9._~+/=-]{8,}'; then
      report "Secret" "$FILE" "$LINE_NO"
    fi

    if printf '%s\n' "$LINE" | grep -Eq -- '-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----'; then
      report "Private key" "$FILE" "$LINE_NO"
    fi

    if printf '%s\n' "$LINE" | grep -Eq 'eyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}'; then
      report "JWT token" "$FILE" "$LINE_NO"
    fi

    if printf '%s\n' "$LINE" | grep -Eiq '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'; then
      report "Email address" "$FILE" "$LINE_NO"
    fi
  done < "$FILE"
done

if [ "$FAILED" -ne 0 ]; then
  echo ""
  echo "========================================"
  echo " SECURITY SCAN FAILED"
  echo "========================================"
  echo "Remove sensitive values and retry the push."
  exit 1
fi

echo "Security scan passed."
exit 0
