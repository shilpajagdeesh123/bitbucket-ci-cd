@echo off
setlocal

git rev-parse --show-toplevel >nul 2>&1
if errorlevel 1 (
    echo ERROR: Run this command from inside the cloned repository.
    exit /b 1
)

if not exist ".githooks\pre-push" (
    echo ERROR: .githooks\pre-push not found.
    exit /b 1
)

if not exist ".security\security-scan.sh" (
    echo ERROR: .security\security-scan.sh not found.
    exit /b 1
)

git config core.hooksPath .githooks
if errorlevel 1 (
    echo ERROR: Failed to configure Git hooks path.
    exit /b 1
)

echo ========================================
echo  Security hook installed
echo ========================================
for /f "delims=" %%A in ('git config core.hooksPath') do echo core.hooksPath = %%A
echo.
echo Every git push in this repository will now run:
echo   .githooks\pre-push
echo     -^> .security\security-scan.sh

exit /b 0
